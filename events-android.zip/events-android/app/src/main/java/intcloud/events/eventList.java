package intcloud.events;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.ParseException;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;


public class eventList extends Activity {


    String url = "https://s3-ap-southeast-2.amazonaws.com/bridj-coding-challenge/events.json";

    ProgressDialog progressDialog;
    List<List_item> event_list = new ArrayList<List_item>();
    ListAdapter MyListAdapter;
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.events);

        MyListAdapter = new ListAdapter();
        if (isConnected()) {
            new getEventDataFromServer().execute(url);
        } else {
            showDialog("Events", "No Internet");
        }
    }

    //general purpose dialog
    public void showDialog(String title, String dialogMsg) {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(getBaseContext());

        // Setting Dialog Title
        alertDialog.setTitle(title);

        // Setting Dialog Message
        alertDialog.setMessage(dialogMsg);
        alertDialog.setCancelable(true);
        alertDialog.setPositiveButton("OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
        alertDialog.show();
    }

    public List<List_item> getDataForListView() {
        return event_list;
    }

    // parse json from GET request
    public void parse_result(JSONObject result) {

        String str;
        try {

            JSONArray ar = new JSONArray();
            ar = result.getJSONArray("events");
            int n = ar.length();

            for (int i = 0, size = n; i < size; i++) {
                JSONObject objectInArray = ar.getJSONObject(i);
                List_item item = new List_item();
                item.name = objectInArray.getString("name");
                item.theater = objectInArray.getString("venue");
                int price = objectInArray.getInt("price");
                item.price = String.valueOf(price);
                int noSeat = objectInArray.getInt("available_seats");

                str = objectInArray.getString("date");
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
                try {
                    Date date = format.parse(str);
                    item.date = date;
                    SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
                    String newFormat = formatter.format(date);
                    item.theday = "Date: " + newFormat;
                } catch (java.text.ParseException e) {
                    e.printStackTrace();
                    Toast.makeText(getBaseContext(), "fail parse date str", Toast.LENGTH_LONG).show();
                }
                if (noSeat > 0) {
                    event_list.add(item);
                }
            }
            // sort on date
            Collections.sort(event_list, new Comparator<List_item>() {
                @Override
                public int compare(List_item lhs, List_item rhs) {
                    return lhs.date.compareTo(rhs.date);
                }
            });
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(getBaseContext(), "fail parse Json", Toast.LENGTH_LONG).show();
        }
    }

    //check if there is connection
    public boolean isConnected() {
        ConnectivityManager connMgr = (ConnectivityManager) getSystemService(this.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected())
            return true;
        else
            return false;
    }


    public class List_item {
        String theday;
        String name;
        String theater;
        String price;
        Date date;
    }

    public class ListAdapter extends BaseAdapter {

        List<List_item> list_data = getDataForListView();

        @Override
        public int getCount() {
            return list_data.size();
        }

        @Override
        public List_item getItem(int arg0) {
            return list_data.get(arg0);
        }

        @Override
        public long getItemId(int arg0) {
            return arg0;
        }

        @Override
        public View getView(int arg0, View arg1, ViewGroup arg2) {

            if (arg1 == null) {
                LayoutInflater inflater = (LayoutInflater) getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                arg1 = inflater.inflate(R.layout.listitem, arg2, false);
            }
            TextView name = (TextView) arg1.findViewById(R.id.name);
            TextView theater = (TextView) arg1.findViewById(R.id.textView1);
            TextView price = (TextView) arg1.findViewById(R.id.textView2);
            TextView theday = (TextView) arg1.findViewById(R.id.textView3);
            List_item item = list_data.get(arg0);
            name.setText(item.name);
            theater.setText(item.theater);
            price.setText(item.price);
            theday.setText(item.theday);

            return arg1;
        }

        public List_item get_item(int position) {
            return list_data.get(position);
        }

    }

    private class getEventDataFromServer extends AsyncTask<String, Void, JSONObject> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = ProgressDialog.show(eventList.this,
                    "", "");
        }

        @Override
        protected JSONObject doInBackground(String... params) {
            String response;
            try {
                HttpClient httpclient = new DefaultHttpClient();
                // make GET request to the given URL
                HttpResponse httpResponse = httpclient.execute(new HttpGet(url));
                HttpEntity httpEntity = httpResponse.getEntity();
                response = EntityUtils.toString(httpEntity);
                return new JSONObject(response);

            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            super.onPostExecute(result);
            progressDialog.dismiss();
            if (result != null) {
                try {
                    parse_result(result);
                    listView = (ListView) findViewById(R.id.mobile_list);
                    listView.setAdapter(MyListAdapter);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                Toast.makeText(getBaseContext(), "Network Problem", Toast.LENGTH_LONG).show();
            }
        }
    }
}
  
