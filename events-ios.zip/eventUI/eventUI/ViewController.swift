//
//  ViewController.swift
//  eventUI
//
//  Created by Admin on 27/11/18.
//  Copyright © 2018 Admin. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    let url = "https://s3-ap-southeast-2.amazonaws.com/bridj-coding-challenge/events.json";
    var paramAr: [eventData] = [];
    @IBAction func btnClk(_ sender: Any) {
        // remove 0 seat
        paramAr = paramAr.filter { $0.available_seats > 0 };
        //sort on date
        paramAr = paramAr.sorted(by: { $0.date.compare($1.date) == .orderedAscending });
        //pass to eventlist child component to display
        self.switchViewControllers(boardName: "eventList", Id: "eventList")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let networkmodel = NetworkModel();
        networkmodel.getRequest(theUrl: url) { responseStr in
            let swiftStr = responseStr.data(using: .utf8)!
            do {
                let swiftData = try JSONDecoder().decode(events.self,
                                                         from: swiftStr); // convert string to object pointer to the type
                self.paramAr = swiftData.events;
                //  print(self.paramAr);
                
            } catch {
                print("is not a valid json object");
                return // break the process bc data is invalid
            }
            
        }
    }


}
extension ViewController: eventListDelegate {
    func eventListReturn(row: Int) {
        // close it from caller
        print(paramAr[row]);
        navigationController?.popViewController(animated: true)
    }
    
    func switchViewControllers(boardName: String, Id: String) {
        
        // switch root view controllers
        let storyboard = UIStoryboard.init(name: boardName, bundle: nil)
        let callee = storyboard.instantiateViewController(withIdentifier: Id) as! EventList;
        callee.paramArray = paramAr;
        callee.delegate = self;
        navigationController?.pushViewController(callee, animated: true)
        
    }
}

