//
//  EventList.swift
//  eventUI
//
//  Created by Admin on 27/11/18.
//  Copyright © 2018 Admin. All rights reserved.
//

import UIKit
protocol eventListDelegate {
    func eventListReturn(row: Int);
}
class EventList: UITableViewController {
    var delegate: eventListDelegate?
    var paramArray: [eventData] = [];
    override func viewDidLoad() {
        super.viewDidLoad()

    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return paramArray.count ;
    }

   
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "eventCell", for: indexPath) as! eventCell;
        cell.nameLb.text = paramArray[indexPath.row].name;
        cell.priceLb.text = "$" + paramArray[indexPath.row].price.description;
        cell.venueLb.text = paramArray[indexPath.row].venue;
        cell.PlayLb.isHidden = !paramArray[indexPath.row].labels.contains("play");

        return cell
    }
  
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // notify parent a row selected
        delegate!.eventListReturn(row: indexPath.row);
      
        
    }
    
}
