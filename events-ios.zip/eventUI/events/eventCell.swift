//
//  eventCell.swift
//  eventUI
//
//  Created by Admin on 27/11/18.
//  Copyright © 2018 Admin. All rights reserved.
//

import UIKit

class eventCell: UITableViewCell {
    @IBOutlet weak var nameLb: UILabel!
    @IBOutlet weak var priceLb: UILabel!
    @IBOutlet weak var venueLb: UILabel!
    @IBOutlet weak var PlayLb: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
