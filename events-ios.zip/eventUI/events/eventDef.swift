//
//  eventDef.swift
//  eventUI
//
//  Created by Admin on 27/11/18.
//  Copyright © 2018 Admin. All rights reserved.
//

import Foundation

struct eventData: Codable {
    let date : String
    let name: String
    let price: Int
    let available_seats: Int
    let venue : String
    let labels : [String]
    enum CodingKeys: String, CodingKey
    {
        case date
        case name
        case price
        case venue
        case available_seats
        case labels
    }
}
struct events: Codable {
     let events:  [eventData]
    enum CodingKeys: String, CodingKey
    {
       case events
    }
}

