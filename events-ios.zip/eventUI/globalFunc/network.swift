import Foundation

public class NetworkModel {
    init() { }

    func getRequest(theUrl: String, _ callback: @escaping (_ in: String) -> ()) {

        let url = URL(string: theUrl)!
        var request = URLRequest(url: url);
        // preset header
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpMethod = "GET";
        
        // Getting response for GET Method
        DispatchQueue.main.async { // run in background
            let task = URLSession.shared.dataTask(with: request) { data, response, error in
                guard let data = data, error == nil else {
                    print(error?.localizedDescription ?? "No data")
                    return // check for fundamental networking error
                }
                // Getting values from JSON Response
                let responseString = String(data: data, encoding: .utf8);
                callback(responseString!);
            }
            task.resume()
        }
    }

    func postRequest <T : Codable>(theUrl: String, bodyStr: String,
                                   decodeClass: T.Type, _ callback: @escaping (_ in: String) -> ()) {

        let url = URL(string: theUrl)!
        var request = URLRequest(url: url);
        // preset header
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpMethod = "POST";
        let swiftStr = bodyStr.data(using: .utf8)!
        do {
            let swiftData = try JSONDecoder().decode(decodeClass.self,
                                                     from: swiftStr); // convert string to object pointer to the type
            let jsonData = try JSONEncoder().encode(swiftData); //encode to Json object
            request.httpBody = jsonData; // pass to the request body

        } catch {
            print("is not a valid json object");
            return // break the process bc data is invalid
        }
        // Getting response for POST Method
        DispatchQueue.main.async { // run in background
            let task = URLSession.shared.dataTask(with: request) { data, response, error in
                guard let data = data, error == nil else {
                    print(error?.localizedDescription ?? "No data")
                    return // check for fundamental networking error
                }
                // Getting values from JSON Response
                let responseString = String(data: data, encoding: .utf8);
                callback(responseString!);
            }
            task.resume()
        }
    }
}
